# 🌧️ RainApp  
*A simple, data‑driven rainfall and lawn‑watering tracker for Windows*

RainApp is a lightweight desktop application for Windows 10–11 that helps homeowners track rainfall, watering events, and lawn moisture conditions. It provides a clean UI for daily data entry, a colour‑coded history table, and a dashboard that estimates soil moisture using a decay‑based model derived from professional lawn‑care advice.

The app is designed to be simple, transparent, and easy to maintain — no cloud services, no databases, just CSV and JSON files stored locally.

---

## 🐍 Python Version & Environment

RainApp is written in **Python 3.14** and uses the following key libraries:

- **tkinter** (standard library) — GUI framework  
- **tkcalendar** — date picker widget  
- **csv**, **json**, **datetime**, **os** — standard library modules  

The executable is built using **PyInstaller** under Python 3.14.

If running from source, ensure you have:

```
Python 3.14.x
pip install tkcalendar
pip install pyinstaller   # only needed for building the EXE
```

---

## 🌱 Features

### ✔ Daily rainfall logging  
Record rainfall from two sources:  
- **Rain_mm** (user‑entered)  
- **BOM_mm** (Bureau of Meteorology data)

The app automatically chooses the first valid value.

### ✔ Watering event tracking  
Mark any day as “Watered”.  
This resets the moisture model and is visually highlighted in the table.

### ✔ Colour‑coded rainfall history  
The table uses intuitive colours:  
- **Green** — Watered  
- **Blue** — Rain > 0 mm  
- **Tan** — Rain = 0 mm  

### ✔ Dashboard summary  
The dashboard displays:  
- Moisture balance (decay model)  
- Watering needed?  
- Last watering date  
- Last rainfall date  
- Days since last rain  
- Missing days  
- A legend explaining the colour coding  

### ✔ Missing‑day detection  
Automatically identifies gaps in the date sequence and allows you to view missing dates.

### ✔ Persistent settings  
Threshold and period values are saved in `settings.json`.

---

## 🌦 Moisture Model (Decay‑Based)

RainApp implements a generalised moisture‑decay model based on the rule provided by a lawn‑care professional:

> “If, over **N days** after watering, rainfall is less than **T mm**, water again.”

This rule is converted into a simple, explainable soil‑moisture model:

- Moisture starts at **T mm** immediately after watering  
- Moisture decays by **T / N mm per day**  
- Rainfall replenishes moisture  
- Moisture is capped at **T mm**  
- Watering is required when moisture reaches **0 mm**

This model adapts automatically when the user changes the threshold or the period.

---

## 🧩 How the App Works

### Data Storage  
RainApp uses two local files:

| File | Purpose |
|------|---------|
| `rain_data.csv` | Daily rainfall and watering history |
| `settings.json` | Threshold, period, and data file settings |

### UI Structure  
- **Top section:** Data entry form  
- **Middle section:** Colour‑coded Treeview table  
- **Bottom section:** Dashboard with moisture model and status indicators  

### Key Logic Components  
- `_effective_mm()` — chooses the best rainfall value  
- `_compute_moisture_balance()` — decay‑based moisture model  
- `_moisture_mode_watering_needed()` — watering decision  
- `_compute_missing_dates()` — identifies gaps in the dataset  
- `_update_dashboard()` — updates all dashboard fields  

---

## 🖥️ Windows 10–11 Executable Deployment

RainApp is packaged as a **stand‑alone Windows executable** using PyInstaller.

### Required Runtime Files  
Keep these files together in the same folder:

```
rain_app.exe
rain.ico
rain_data.csv
settings.json
```

### Building the Executable

From the project directory:

```
E:\SoftwareProjects\GithubRepos\RainFall
```

Run the batch file:

```
PyInstaller_cmd.bat
```

Contents of `PyInstaller_cmd.bat`:

```
py -3.14 -m PyInstaller --noconsole --onefile --icon=rain.ico rain_app.py
```

This produces:

```
dist\rain_app.exe
```

Copy the EXE and required runtime files into a deployment folder.

---

## 📂 Project Structure

```
RainFall/
│
├── rain_app.py
├── rain_data.csv
├── settings.json
├── rain.ico
├── PyInstaller_cmd.bat
└── README.md
```

---

## 🚀 Getting Started

1. Download or clone the repository  
2. Run `rain_app.py` with Python 3.14 **or** use the packaged `rain_app.exe`  
3. Enter rainfall and watering data daily  
4. Review the dashboard to determine watering needs  

---

## 📝 License

This project is for personal use.  
You may modify or extend it for your own lawn‑care needs.

---
End